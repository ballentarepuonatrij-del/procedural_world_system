#include "planet/terrain_mesh.hpp"
#include "planet/rivers.hpp"
#include <stdexcept>

namespace planet {
PlantMesh makePlantMesh(std::span<const PlantSite> sites,Vec3 anchor,Vec3 eastAxis,Vec3 northAxis,double radius,const Flora& flora) {
    PlantMesh result;std::array<bool,speciesCount> species{};double nearest=1e30;
    const auto local=[&](Vec3 p){return Vec3{dot(p,eastAxis),dot(p,anchor),dot(p,northAxis)};};
    std::vector<const PlantSite*> ordered;ordered.reserve(sites.size());
    for(const auto& site:sites) ordered.push_back(&site);
    std::stable_sort(ordered.begin(),ordered.end(),[&](const auto a,const auto b){return length(a->object.up-anchor)<length(b->object.up-anchor);});
    for(const auto* entry:ordered) {
        const auto& site=*entry;
        const auto object=grownObject(site.object,&flora);if(object.height<.015) continue;
        const double distance=length(object.up-anchor)*radius;
        const auto up=local(object.up);
        const bool simple=distance>(object.kind==DetailKind::Grass || object.kind==DetailKind::Shrub ? 24 : 60);
        const bool shadow=distance<=std::max(160.,std::min(240.,object.height*4)) && object.castsSurfaceShadow();
        const bool flexible=flexiblePlant(object) && distance<foliageMotionRadius && result.foliage.size()<maximumFoliagePlants;
        const int slot=flexible ? static_cast<int>(result.foliage.size()) : -1;
        if(flexible) result.foliage.push_back(foliageRoot(object,radius));
        auto& vertices=flexible ? result.moving : result.vertices;
        FoliageRange range{vertices.size(),0,slot};
        const bool leaves=flexible && distance<36 && result.leafVertices+4096<=maximumLeafVertices;
        for(const auto& face:detailMesh(object,site.base,up,local(east(object.up)),simple,leaves)) {
            if(face.microFoliage && result.leafVertices+3>maximumLeafVertices) continue;
            const auto& t=face.triangle;const auto n=normalized(cross(t.b-t.a,t.c-t.a));
            const double cover=smoothstep(0.,.08,site.snowDepth)*smoothstep(.15,.6,dot(n,up));
            const Color color{static_cast<float>(mix(face.color.r,.88,cover)),static_cast<float>(mix(face.color.g,.93,cover)),static_cast<float>(mix(face.color.b,.97,cover))};
            unsigned corner=0;const std::array flutter{face.flutter.x,face.flutter.y,face.flutter.z};
            for(const auto p:{t.a,t.b,t.c}) {
                const double vertical=clamp(dot(p-site.base,up)/object.height,0.,1.);
                const double flex=flexible ? std::pow(clamp((vertical-.1)/.9,0.,1.),2) : 0;
                vertices.push_back({p,n,color,static_cast<float>(flex),static_cast<float>(object.height),
                    flexible ? static_cast<float>(result.foliage.back().phase) : 0.f,
                    static_cast<float>(flutter[corner++]),static_cast<float>(face.leafPhase),static_cast<float>(slot)});
            }
            // Cached crown volumes approximate the canopy shadow. Fine leaves
            // do not multiply the stencil geometry or force per-frame rebuilds.
            if(face.microFoliage) result.leafVertices+=3;
            else if(shadow) result.casters.push_back(t);
        }
        range.count=vertices.size()-range.first;if(flexible) result.ranges.push_back(range);
        ++result.objects;
        if(object.species==Species::None) continue;
        ++result.plants;species[static_cast<unsigned>(object.species)]=true;result.heightSum+=object.height;
        result.maximumHeight=std::max(result.maximumHeight,object.height);
        if(object.kind==DetailKind::Tree) ++result.trees;
        if(object.lianas()) ++result.lianaHosts;
        if(plantTraits(object.species).aquatic) {if(freshwaterPlant(object.species)) ++result.freshwater;else ++result.marine;}
        if(object.flowers.bloom>.02) ++result.flowering;
        if(object.flowers.buds>.02) ++result.budding;
        if(object.flowers.seeds>.02) ++result.seedHeads;
        if(distance<nearest) {nearest=distance;result.focus=object;}
    }
    result.species=static_cast<std::size_t>(std::count(species.begin(),species.end(),true));return result;
}
namespace {
std::vector<double> terrainAxis(double center,double step) {
    std::vector<double> points;
    // Nested powers-of-two lattices in a fixed cube-face chart. The sample
    // positions stay on the planet as the camera moves; only LOD membership changes.
    for(double spacing=step,extent=step*8;extent<=262144;spacing*=2,extent*=2) {
        const auto first=static_cast<std::int64_t>(std::ceil((center-extent)/spacing));
        const auto last=static_cast<std::int64_t>(std::floor((center+extent)/spacing));
        for(auto i=first;i<=last;++i) {
            const double position=static_cast<double>(i)*spacing;
            if(spacing==step || std::abs(position-center)>extent/2) points.push_back(position);
        }
    }
    std::sort(points.begin(),points.end());
    points.erase(std::unique(points.begin(),points.end()),points.end());
    return points;
}
}
double terrainSpacing(const World& world,Vec3 observer,double altitude,double minimumStep) {
    if(!std::isfinite(length(observer)) || length(observer)<.5 || !std::isfinite(altitude) ||
       !std::isfinite(minimumStep) || minimumStep<2 || minimumStep>8192)
        throw std::invalid_argument("Invalid terrain mesh location or spacing");
    const double aboveGround=std::max(0.0,altitude-world.surface(observer));
    const int level=clamp(static_cast<int>(std::floor(std::log2(std::max(1.0,aboveGround/64)))),0,12);
    return std::max(minimumStep,std::ldexp(2.0,level));
}
TerrainMesh makeTerrainMesh(const World& world,const Hydrology& water,Vec3 observer,double altitude,double seconds,double minimumStep) {
    if(!std::isfinite(seconds)) throw std::invalid_argument("Invalid terrain mesh clock");
    TerrainMesh mesh;

    // Local +Z points south so the rendering basis is right-handed.
    mesh.anchor=observer; mesh.east=east(mesh.anchor); mesh.north=-north(mesh.anchor);
    const double radius=world.config().radius;
    mesh.spacing=terrainSpacing(world,observer,altitude,minimumStep);
    mesh.eyeHeight=altitude;
    Vec3 face;
    if(std::abs(mesh.anchor.x)>=std::abs(mesh.anchor.y) && std::abs(mesh.anchor.x)>=std::abs(mesh.anchor.z))
        face={std::copysign(1.0,mesh.anchor.x),0,0};
    else if(std::abs(mesh.anchor.y)>=std::abs(mesh.anchor.z)) face={0,std::copysign(1.0,mesh.anchor.y),0};
    else face={0,0,std::copysign(1.0,mesh.anchor.z)};
    const Vec3 reference=std::abs(face.y)<0.5 ? Vec3{0,1,0} : Vec3{0,0,1};
    const Vec3 right=normalized(cross(reference,face)), down=cross(right,face);
    const auto cave=world.caveSite(mesh.anchor);
    const double projection=radius/dot(mesh.anchor,face);
    auto xs=terrainAxis(dot(mesh.anchor,right)*projection,mesh.spacing);
    auto ys=terrainAxis(dot(mesh.anchor,down)*projection,mesh.spacing);
    if(water.enabled() && mesh.spacing<=8 && altitude-water.ground(world,mesh.anchor)<1200) {
        double minX=1e30,maxX=-1e30,minY=1e30,maxY=-1e30;
        for(int z:{0,Hydrology::resolution-1}) for(int x:{0,Hydrology::resolution-1}) {
            const auto q=water.directionAt(water.cellX(x),water.cellZ(z));
            const double k=radius/dot(q,face),cx=dot(q,right)*k,cy=dot(q,down)*k;
            minX=std::min(minX,cx); maxX=std::max(maxX,cx); minY=std::min(minY,cy); maxY=std::max(maxY,cy);
        }
        const auto refine=[](std::vector<double>& axis,double low,double high) {
            for(double v=std::ceil(low/4)*4;v<=high;v+=4) axis.push_back(v);
            std::sort(axis.begin(),axis.end()); axis.erase(std::unique(axis.begin(),axis.end()),axis.end());
        };
        refine(xs,minX,maxX); refine(ys,minY,maxY);
    }
    if(cave && altitude-world.surface(mesh.anchor)<1200) {
        double minX=1e30,maxX=-1e30,minY=1e30,maxY=-1e30;
        for(double z:{-85.,290.}) for(double x:{-110.,110.}) {
            const auto q=cave->directionAt(x,z); const double k=radius/dot(q,face);
            minX=std::min(minX,dot(q,right)*k); maxX=std::max(maxX,dot(q,right)*k);
            minY=std::min(minY,dot(q,down)*k); maxY=std::max(maxY,dot(q,down)*k);
        }
        const double step=std::max(mesh.spacing,std::pow(2.0,std::ceil(std::log2(2/std::pow(dot(cave->anchor,face),2)))));
        const auto refine=[&](std::vector<double>& axis,double low,double high) {
            for(double v=std::ceil(low/step)*step;v<=high;v+=step) axis.push_back(v);
            std::sort(axis.begin(),axis.end()); axis.erase(std::unique(axis.begin(),axis.end()),axis.end());
        };
        refine(xs,minX,maxX); refine(ys,minY,maxY);
    }
    mesh.rivers.clear();
    if(world.modules().enabled(Module::Rivers)) {
        const auto network=world.waterNetwork();mesh.rivers=network->nearby(mesh.anchor,2200);
        const auto river=network->sample(mesh.anchor);
        if(mesh.spacing<=8 && river.channel && river.distance<river.width*.5+40 && altitude-world.surface(mesh.anchor)<250) {
            const double extent=clamp(river.width*3,40.,192.),spacing=river.width<4 ? .5 : river.width<16 ? 2. : 8.;
            const auto refine=[&](std::vector<double>& axis,double center) {
                for(double p=std::ceil((center-extent)/spacing)*spacing;p<=center+extent;p+=spacing) axis.push_back(p);
                std::sort(axis.begin(),axis.end());axis.erase(std::unique(axis.begin(),axis.end()),axis.end());
            };
            refine(xs,dot(mesh.anchor,right)*projection);refine(ys,dot(mesh.anchor,down)*projection);
        }
    }
    const int columns=static_cast<int>(xs.size()),rows=static_cast<int>(ys.size());
    const double aboveGround=std::max(0.0,altitude-world.surface(mesh.anchor));
    struct Vertex { Vec3 position; Color color; double u,v; float gridAlpha; Vec3 normal{}; bool ocean{}; Vec3 unit{}; double height{}; CaveColumn cavity{}; Sample sample{}; GroundSample ground{}; double snow=0; SurfaceMaterial material{}; bool sheltered=false; };
    std::vector<Vertex> vertices(xs.size()*ys.size());
    mesh.waterVertices.clear(); mesh.waterTriangles.clear();
    mesh.waterVertices.reserve(vertices.size());
    for(int y=0;y<rows;++y) for(int x=0;x<columns;++x) {
        const Vec3 p=normalized(face*radius+right*xs[static_cast<std::size_t>(x)]+down*ys[static_cast<std::size_t>(y)]);
        const auto sample=world.sample(p,seconds);
        const auto ground=water.sample(p);
        const auto river=world.modules().enabled(Module::Rivers) ? world.waterNetwork()->sample(p) : RiverSample{};
        const double original=sample.elevation;
        const double h=ground.available ? river.channel ? original+ground.bedChange*ground.weight : mix(original,ground.bed,ground.weight) : original;
        const double snow=cave && cave->protectedGround(p) ? 0 : water.snow.depth(p,sample);
        const Vec3 relative=p*(radius+h+snow)-mesh.anchor*radius;
        // World-anchored coordinates keep the material stationary when the local mesh recentres.
        const Vec3 global=p*(radius+h);
        const Vec3 position{dot(relative,mesh.east),dot(relative,mesh.anchor),dot(relative,mesh.north)};
        const double localSpacing=std::max(x>0 ? xs[static_cast<std::size_t>(x)]-xs[static_cast<std::size_t>(x-1)] : mesh.spacing,
                                           y>0 ? ys[static_cast<std::size_t>(y)]-ys[static_cast<std::size_t>(y-1)] : mesh.spacing);
        double waterBed=h;
        if(cave && cave->coastal) {const auto c=cave->column(p);if(c.valid()) waterBed=std::min(waterBed,c.floor);}
        mesh.waterVertices.push_back({p,position,waterBed,world.modules().enabled(Module::Ocean) || world.modules().enabled(Module::InlandWaters) || (ground.available && ground.weight>0),river.wet && river.level>world.config().seaLevel+.02,localSpacing,sample.inland,sample.landform==Landform::Wetland,sample.waterLevel});
        const float alpha=static_cast<float>(1-smoothstep(1500+aboveGround*4,10000+aboveGround*12,std::hypot(position.x,position.z)));
        const bool sheltered=cave && cave->protectedGround(p);
        vertices[static_cast<std::size_t>(y*columns+x)]={position,{},
            (global.x+global.z)*0.25,(global.y+global.z*0.37)*0.25,alpha,{},sample.ocean,p,h+snow,
            cave ? cave->column(p) : CaveColumn{},sample,ground,snow,{},sheltered};
    }
    const auto at=[&](int x,int y)->Vertex& { return vertices[static_cast<std::size_t>(y*columns+x)]; };
    for(int y=0;y<rows;++y) for(int x=0;x<columns;++x) {
        auto& v=at(x,y);
        v.normal=normalized(cross(at(std::min(x+1,columns-1),y).position-at(std::max(x-1,0),y).position,
                                  at(x,std::max(y-1,0)).position-at(x,std::min(y+1,rows-1)).position));
        const Vec3 worldNormal=mesh.east*v.normal.x+mesh.anchor*v.normal.y+mesh.north*v.normal.z;
        const auto material=surfaceMaterial(v.sample,v.unit*(radius+v.height-v.snow),dot(worldNormal,v.unit),
            v.snow,v.ground,world.config().seed,world.modules().enabled(Module::Biomes),v.sheltered);
        v.color=material.albedo;v.material=material.surface;
        // Grazing lines cover subpixel cells near the horizon. Fade them instead
        // of accumulating a bright, flickering band of overlapping edges.
        const double incidence=dot(v.normal,normalized(Vec3{0,mesh.eyeHeight,0}-v.position));
        v.gridAlpha*=static_cast<float>(smoothstep(0.0,0.08,incidence));
    }
    for(int y=0;y<rows-1;++y) for(int x=0;x<columns-1;++x) {
        const auto a=static_cast<std::size_t>(y*columns+x),b=a+1,c=a+static_cast<std::size_t>(columns),d=c+1;
        for(const auto tri:{std::array<std::size_t,3>{a,c,d},std::array<std::size_t,3>{a,d,b}})
            if(mesh.waterVertices[tri[0]].available && mesh.waterVertices[tri[1]].available && mesh.waterVertices[tri[2]].available) mesh.waterTriangles.push_back(tri);
    }
    mesh.waterRevision=water.revision(); mesh.waterSteps=water.steps();
    const auto interpolate=[&](const Vertex& a,const Vertex& b,double t) {
        Vertex v=a; v.unit=normalized(a.unit*(1-t)+b.unit*t); v.height=world.elevation(v.unit);
        const Vec3 relative=v.unit*(radius+v.height)-mesh.anchor*radius;
        v.position={dot(relative,mesh.east),dot(relative,mesh.anchor),dot(relative,mesh.north)};
        v.normal=normalized(a.normal*(1-t)+b.normal*t);
        v.color={static_cast<float>(mix(a.color.r,b.color.r,t)),static_cast<float>(mix(a.color.g,b.color.g,t)),static_cast<float>(mix(a.color.b,b.color.b,t))};
        for(std::size_t i=0;i<4;++i) v.material.weights[i]=static_cast<float>(mix(a.material.weights[i],b.material.weights[i],t));
        v.material.wetness=static_cast<float>(mix(a.material.wetness,b.material.wetness,t));
        v.material.backgroundWetness=static_cast<float>(mix(a.material.backgroundWetness,b.material.backgroundWetness,t));
        v.u=mix(a.u,b.u,t); v.v=mix(a.v,b.v,t); v.gridAlpha=static_cast<float>(mix(a.gridAlpha,b.gridAlpha,t));
        v.cavity=cave ? cave->column(v.unit) : CaveColumn{}; return v;
    };
    const auto field=[](const Vertex& v,int plane) {
        if(plane==0) return v.cavity.field;
        if(plane==1) return -std::min(v.cavity.ceiling-v.height,v.height-v.cavity.floor);
        return v.height-(plane==2 ? v.cavity.floor : v.cavity.ceiling);
    };
    const auto clip=[&](const std::vector<Vertex>& input,int plane) {
        std::vector<Vertex> output;
        if(input.empty()) return output;
        for(std::size_t i=0;i<input.size();++i) {
            const auto& a=input[i]; const auto& b=input[(i+1)%input.size()];
            const bool inside=field(a,plane)>=0,next=field(b,plane)>=0;
            if(inside) output.push_back(a);
            if(inside!=next) {
                double lo=0,hi=1;
                for(int j=0;j<14;++j) { const double mid=(lo+hi)/2; if((field(interpolate(a,b,mid),plane)>=0)==inside) lo=mid; else hi=mid; }
                auto v=interpolate(a,b,(lo+hi)/2);
                if(plane==0) { v.cavity.field=0; v.cavity.floor=v.cavity.ceiling=(v.cavity.floor+v.cavity.ceiling)/2; }
                else if(plane==2) v.cavity.floor=v.height;
                else if(plane==3) v.cavity.ceiling=v.height;
                output.push_back(v);
            }
        }
        return output;
    };
    const auto terrainVertex=[&](const Vertex& v) {
        mesh.terrain.push_back({v.position,v.normal,v.color,v.u,v.v,v.material});
    };

    for(int y=0;y<rows-1;++y) for(int x=0;x<columns-1;++x) {
        for(const auto& tri:{std::array<Vertex,3>{at(x,y),at(x,y+1),at(x+1,y+1)},std::array<Vertex,3>{at(x,y),at(x+1,y+1),at(x+1,y)}}) {
            const auto polygon=cave ? clip({tri.begin(),tri.end()},1) : std::vector<Vertex>{tri.begin(),tri.end()};
            for(std::size_t i=1;i+1<polygon.size();++i) {
                const auto a=polygon[0].position,b=polygon[i].position,c=polygon[i+1].position;
                if(std::max({std::hypot(a.x,a.z),std::hypot(b.x,b.z),std::hypot(c.x,c.z)})<1200) mesh.casters.push_back({a,b,c});
                terrainVertex(polygon[0]); terrainVertex(polygon[i]); terrainVertex(polygon[i+1]);
            }
        }
    }



    if(cave) for(int y=0;y<rows-1;++y) for(int x=0;x<columns-1;++x) {
        for(const auto& tri:{std::array<Vertex,3>{at(x,y),at(x,y+1),at(x+1,y+1)},std::array<Vertex,3>{at(x,y),at(x+1,y+1),at(x+1,y)}}) {
            if(std::max({tri[0].cavity.field,tri[1].cavity.field,tri[2].cavity.field})<0) continue;
            const auto footprint=clip({tri.begin(),tri.end()},0);
            for(int side=2;side<=3;++side) {
                const auto polygon=clip(footprint,side);
                const auto point=[&](const Vertex& v) {
                    const double h=side==2 ? v.cavity.floor : v.cavity.ceiling;
                    const Vec3 p=v.unit*(radius+h)-mesh.anchor*radius;
                    return Vec3{dot(p,mesh.east),dot(p,mesh.anchor),dot(p,mesh.north)};
                };
                for(std::size_t i=1;i+1<polygon.size();++i) {
                    const auto a=point(polygon[0]),b=point(polygon[i]),c=point(polygon[i+1]);
                    auto normal=normalized(cross(b-a,c-a));
                    if((normal.y>0)!=(side==2)) normal=-normal;

                    for(const auto index:{std::size_t{0},i,i+1}) {
                        const auto& v=polygon[index]; const auto p=point(v);
                        const double height=side==2 ? v.cavity.floor : v.cavity.ceiling;
                        const float shade=static_cast<float>(0.83+0.12*std::sin(height*1.5)+0.05*std::sin(height*5));
                        mesh.caves.push_back({p,normal,{0.51f*shade,0.47f*shade,0.38f*shade},v.u,v.v,SurfaceMaterial{{1,0,0,0},.08f,.08f}});
                    }

                }
            }
        }
    }



    const auto edge=[&](int ax,int ay,int bx,int by,bool diagonal) {
        const auto& a=vertices[static_cast<std::size_t>(ay*columns+ax)];
        const auto& b=vertices[static_cast<std::size_t>(by*columns+bx)];
        if(a.gridAlpha==0 && b.gridAlpha==0) return;
        if(cave && (field(a,1)<0 || field(b,1)<0)) return;
        const auto vertex=[&](const Vertex& v) {
            mesh.grid.push_back({v.position,v.gridAlpha*(diagonal ? 0.34f : 0.75f)});
        };
        vertex(a); vertex(b);
    };
    for(int y=0;y<rows;++y) for(int x=0;x<columns;++x) {
        if(x+1<columns) edge(x,y,x+1,y,false);
        if(y+1<rows) edge(x,y,x,y+1,false);
        // Match the diagonal of the filled triangle strip, including its depth.
        if(x+1<columns && y+1<rows) edge(x,y,x+1,y+1,true);
    }

    mesh.plants.clear();
    if(aboveGround<1800 && minimumStep<=8) {
        const auto objects=surfaceSites(world,mesh.anchor,420,aboveGround<100);
        for(const auto& object:objects) {
            const double distance=length(object.up-mesh.anchor)*radius;
            const double range=object.kind==DetailKind::Tree ? 420 : (object.kind==DetailKind::Rock ? 220 : 80);
            if(distance>range) continue;
            // Seat objects on the actual rendered triangle. Distant LOD samples
            // can differ from the exact collision height; roots must not float.
            const double project=radius/dot(object.up,face);
            const double x=dot(object.up,right)*project,y=dot(object.up,down)*project;
            const int ix=clamp(static_cast<int>(std::upper_bound(xs.begin(),xs.end(),x)-xs.begin())-1,0,columns-2);
            const int iy=clamp(static_cast<int>(std::upper_bound(ys.begin(),ys.end(),y)-ys.begin())-1,0,rows-2);
            const double tx=clamp((x-xs[static_cast<std::size_t>(ix)])/(xs[static_cast<std::size_t>(ix+1)]-xs[static_cast<std::size_t>(ix)]),0.0,1.0);
            const double ty=clamp((y-ys[static_cast<std::size_t>(iy)])/(ys[static_cast<std::size_t>(iy+1)]-ys[static_cast<std::size_t>(iy)]),0.0,1.0);
            const Vec3 a=at(ix,iy).position,d=at(ix+1,iy+1).position;
            Vec3 base=tx>=ty ? a*(1-tx)+at(ix+1,iy).position*(tx-ty)+d*ty
                                  : a*(1-ty)+at(ix,iy+1).position*(ty-tx)+d*tx;
            if(object.species==Species::WaterLily) {
                const auto relative=object.up*(radius+object.elevation)-mesh.anchor*radius;
                base={dot(relative,mesh.east),dot(relative,mesh.anchor),dot(relative,mesh.north)};
            }
            double snow=0;
            if(water.snow.enabled() && !plantTraits(object.species).aquatic) {
                const auto pack=water.snow.sample(object.up);
                snow=pack.available && pack.weight==1 ? pack.depth : water.snow.depth(object.up,world.sample(object.up,seconds));
            }
            mesh.plants.push_back({object,base,snow});
        }
    }
    if(aboveGround<80 && minimumStep<=8) {
        std::vector<std::pair<Vec3,double>> obstacles;
        for(const auto& site:mesh.plants) if(site.object.collisionRadius()>0 && length(site.object.up-mesh.anchor)*radius<grassRadius+5)
            obstacles.emplace_back(site.base,site.object.collisionRadius()+.08);
        mesh.grass=makeGrassRoots(world,observer,[&](Vec3 up) {
            const double scale=radius/dot(up,face),x=dot(up,right)*scale,y=dot(up,down)*scale;
            const int ix=clamp(static_cast<int>(std::upper_bound(xs.begin(),xs.end(),x)-xs.begin())-1,0,columns-2);
            const int iy=clamp(static_cast<int>(std::upper_bound(ys.begin(),ys.end(),y)-ys.begin())-1,0,rows-2);
            const double tx=clamp((x-xs[static_cast<std::size_t>(ix)])/(xs[static_cast<std::size_t>(ix+1)]-xs[static_cast<std::size_t>(ix)]),0.,1.);
            const double ty=clamp((y-ys[static_cast<std::size_t>(iy)])/(ys[static_cast<std::size_t>(iy+1)]-ys[static_cast<std::size_t>(iy)]),0.,1.);
            const auto& a=at(ix,iy);const auto& b=tx>=ty ? at(ix+1,iy) : at(ix,iy+1);const auto& c=at(ix+1,iy+1);
            const double wa=1-std::max(tx,ty),wb=std::abs(tx-ty),wc=std::min(tx,ty);
            GrassGround ground;ground.base=a.position*wa+b.position*wb+c.position*wc;
            ground.normal=normalized(cross(b.position-a.position,c.position-a.position));
            if(ground.normal.y<0) ground.normal=-ground.normal;
            ground.sample=a.sample;ground.sample.elevation=(a.height-a.snow)*wa+(b.height-b.snow)*wb+(c.height-c.snow)*wc;
            ground.sample.temperature=a.sample.temperature*wa+b.sample.temperature*wb+c.sample.temperature*wc;
            ground.sample.precipitation=a.sample.precipitation*wa+b.sample.precipitation*wb+c.sample.precipitation*wc;
            ground.sample.sand=a.sample.sand*wa+b.sample.sand*wb+c.sample.sand*wc;
            ground.sample.waterDepth=a.sample.waterDepth*wa+b.sample.waterDepth*wb+c.sample.waterDepth*wc;
            ground.sample.waterDepth=std::max(ground.sample.waterDepth,a.ground.depth*a.ground.weight*wa+b.ground.depth*b.ground.weight*wb+c.ground.depth*c.ground.weight*wc);
            const auto normal=normalized(a.normal*wa+b.normal*wb+c.normal*wc);
            ground.slope=std::hypot(normal.x,normal.z)/std::max(.01,normal.y);
            ground.snow=a.snow*wa+b.snow*wb+c.snow*wc;
            ground.supported=!(cave && cave->protectedGround(up));
            for(const auto& [base,r]:obstacles) if(std::hypot(base.x-ground.base.x,base.z-ground.base.z)<r+.32) {ground.supported=false;break;}
            return ground;
        });
    }
    mesh.seconds=seconds;mesh.snowRevision=water.snow.revision();return mesh;
}
} // namespace planet
