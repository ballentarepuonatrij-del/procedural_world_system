#include "planet/shadows.hpp"

namespace planet {
std::vector<MeshFace> detailMesh(const SurfaceObject& object,Vec3 origin,Vec3 up,Vec3 right,bool simple,bool leafDetail) {
    std::vector<MeshFace> faces;bool sheets=false;
    right=rotate(right,up,object.angle);
    const Vec3 back=cross(right,up);
    const auto transform=[&](Vec3 p) { return origin+right*p.x+up*p.y+back*p.z; };
    const auto triangle=[&](Vec3 a,Vec3 b,Vec3 c,Color color,Vec3 flutter=Vec3{},double phase=0.,bool micro=false) {
        a=transform(a); b=transform(b); c=transform(c);
        if(length(cross(b-a,c-a))>1e-10) faces.push_back({{a,b,c,sheets},color,flutter,phase,micro});
    };
    const auto tube=[&](Vec3 a,Vec3 b,double base,double tip,Color color) {
        const bool wasSheet=sheets;sheets=false;
        const Vec3 axis=normalized(b-a);
        const Vec3 side=normalized(cross(axis,Vec3{0.4,0.1,1})), front=cross(axis,side);
        const int sides=simple ? 4 : 6;
        for(int i=0;i<sides;++i) {
            const Vec3 u=side*std::cos(tau*i/sides)+front*std::sin(tau*i/sides);
            const Vec3 v=side*std::cos(tau*(i+1)/sides)+front*std::sin(tau*(i+1)/sides);
            triangle(a+u*base,a+v*base,b+v*tip,color);
            triangle(a+u*base,b+v*tip,b+u*tip,color);
            triangle(a,a+v*base,a+u*base,color);
            triangle(b,b+u*tip,b+v*tip,color);
        }
        sheets=wasSheet;
    };
    const auto crown=[&](Vec3 center,Vec3 scale,Color color,std::uint64_t salt) {
        const int rings=simple ? 3 : 4, sides=simple ? 6 : 8;
        const auto vertex=[&](int row,int column) {
            column%=sides;
            const double lat=-pi/2+pi*row/rings, angle=tau*column/sides;
            const double rough=0.82+0.30*randomUnit(object.id+salt+static_cast<std::uint64_t>(row*17+column));
            const double core=leafDetail && object.kind!=DetailKind::Rock ? .82 : 1.;
            return center+Vec3{std::cos(lat)*std::cos(angle)*scale.x*rough,
                               std::sin(lat)*scale.y,std::cos(lat)*std::sin(angle)*scale.z*rough}*core;
        };
        for(int row=0;row<rings;++row) for(int column=0;column<sides;++column) {
            const float tint=static_cast<float>(0.83+0.22*randomUnit(object.id+salt+static_cast<std::uint64_t>(row*31+column)));
            const Color shaded{color.r*tint,color.g*tint,color.b*tint};
            const auto a=vertex(row,column),b=vertex(row,column+1),c=vertex(row+1,column),d=vertex(row+1,column+1);
            if(row>0) triangle(a,c,b,shaded);
            if(row+1<rings) triangle(b,c,d,shaded);
        }
        if(leafDetail && object.kind!=DetailKind::Rock && object.plant.stage!=GrowthStage::Dead) {
            // Folded leaf clusters break the crown silhouette nearby. Their
            // stems share the branch deformation; only the free tips flutter.
            const bool previous=sheets;sheets=true;
            const int count=object.kind==DetailKind::Shrub ? 72 : 96;
            const double size=clamp(scale.x*.22,.065,.55);
            for(int i=0;i<count;++i) {
                const auto key=object.id+salt+static_cast<std::uint64_t>(i*71+4100);
                const int row=static_cast<int>(randomUnit(key)*rings),column=static_cast<int>(randomUnit(key+1)*sides);
                auto a=vertex(row,column),b=vertex(row+1,column),c=vertex(row,column+1);
                if(row==0 || (row+1<rings && randomUnit(key+3)>.5)) {a=vertex(row,column+1);b=vertex(row+1,column);c=vertex(row+1,column+1);}
                const double u=std::sqrt(randomUnit(key+4)),v=randomUnit(key+5);
                const auto base=a*(1-u)+b*(u*(1-v))+c*(u*v);
                const auto outward=normalized(base-center);
                const auto direction=normalized(outward+Vec3{.2,.45,.1}),side=normalized(cross(direction,Vec3{.2,1,.3}));
                const auto mid=base+direction*(size*.6),tip=base+direction*(size*1.5);
                const auto ridge=mid+cross(side,direction)*(size*.15);
                const Color tint{color.r*1.06f,color.g*1.08f,color.b*.92f};
                const double phase=tau*randomUnit(key+2),amplitude=size*.16;
                triangle(base,mid+side*(size*.42),ridge,tint,{0,amplitude*.7,amplitude*.5},phase,true);
                triangle(base,ridge,mid-side*(size*.42),color,{0,amplitude*.5,amplitude*.7},phase,true);
                triangle(ridge,mid+side*(size*.42),tip,tint,{amplitude*.5,amplitude*.7,amplitude},phase,true);
                triangle(ridge,tip,mid-side*(size*.42),color,{amplitude*.5,amplitude,amplitude*.7},phase,true);
            }
            sheets=previous;
        }
    };
    const double h=object.height,r=object.radius;
    const float variation=static_cast<float>(0.85+0.30*randomUnit(object.id+11));
    const auto& traits=plantTraits(object.species);
    const float foliage=static_cast<float>(object.plant.foliage);
    const Color leaves{(traits.leaves.r*foliage+.38f*(1-foliage))*variation,
        (traits.leaves.g*foliage+.26f*(1-foliage))*variation,(traits.leaves.b*foliage+.12f*(1-foliage))*variation};
    const auto& floral=flowerTraits(object.species);const auto& flowers=object.flowers;
    const auto bead=[&](Vec3 center,double width,double height,Color color) {
        const bool previous=sheets;sheets=false;
        for(int i=0;i<4;++i) {
            const Vec3 a=center+Vec3{width*std::cos(tau*i/4),0,width*std::sin(tau*i/4)};
            const Vec3 b=center+Vec3{width*std::cos(tau*(i+1)/4),0,width*std::sin(tau*(i+1)/4)};
            triangle(center+Vec3{0,height,0},b,a,color);triangle(center-Vec3{0,height,0},a,b,color);
        }
        sheets=previous;
    };
    const auto flower=[&](Vec3 center,double size,std::uint64_t salt) {
        if(floral.form==FlowerForm::None) return;
        const double visible=std::max({flowers.buds,flowers.bloom,flowers.seeds});if(visible<.015) return;
        size*=std::sqrt(visible)*clamp(object.plant.size,.4,1.);
        const Color seedColor{.48f,.35f,.17f},green{.28f,.46f,.13f};
        if(flowers.bloom<.015) {bead(center,size*.35,size*.55,flowers.seeds>flowers.buds ? seedColor : green);return;}
        const float open=static_cast<float>(flowers.bloom);
        const Color color{floral.petals.r*open+green.r*(1-open),floral.petals.g*open+green.g*(1-open),floral.petals.b*open+green.b*(1-open)};
        if(floral.form==FlowerForm::Ball) {
            bead(center,size,size*.8,color);
            if(!simple) for(int i=0;i<6;++i) bead(center+Vec3{size*.65*std::cos(tau*i/6),size*.25,size*.65*std::sin(tau*i/6)},size*.35,size*.45,color);
            return;
        }
        if(floral.form==FlowerForm::Catkin || (floral.form==FlowerForm::Spike && floral.petalsCount==0)) {
            const double sign=floral.form==FlowerForm::Catkin ? -1. : 1.;
            for(int i=0;i<(simple ? 3 : 6);++i) bead(center+Vec3{size*.12*(i%2 ? 1 : -1),sign*size*i*.65,0},size*.28,size*.45,color);
            return;
        }
        const bool previous=sheets;sheets=true;
        const unsigned petals=simple ? std::min(5U,floral.petalsCount) : floral.petalsCount;
        const double rotation=tau*randomUnit(object.id+salt),cup=floral.form==FlowerForm::Cup ? .5 : floral.form==FlowerForm::Bell ? -.65 : .1;
        for(unsigned i=0;i<petals;++i) {
            const double angle=tau*i/petals+rotation;
            const Vec3 direction{std::cos(angle),0,std::sin(angle)},side{-std::sin(angle),0,std::cos(angle)};
            const Vec3 a=center+direction*(size*.16),tip=center+direction*size+Vec3{0,size*cup,0};
            const Vec3 middle=center+direction*(size*.7)+Vec3{0,size*cup*.7,0};
            const double width=size*std::sin(pi/petals)*.90;
            triangle(a,middle+side*width,tip,color);triangle(a,tip,middle-side*width,color);
        }
        const Color disk=object.species==Species::Poppy ? Color{.14f,.09f,.08f} : Color{.96f,.72f,.10f};
        bead(center+Vec3{0,size*.07,0},size*.24,size*.10,disk);
        sheets=previous;
    };
    if(object.species==Species::WaterLily) {
        const double level=object.waterDepth*clamp(object.plant.size*2,0.,1.)+.025;
        tube({0,0,0},{0,level,0},.012,.007,leaves);sheets=true;
        for(int leaf=0;leaf<(simple ? 2 : 4);++leaf) {
            const double angle=tau*leaf/4;const Vec3 center{std::cos(angle)*r*.55,level,std::sin(angle)*r*.55};
            const int sides=simple ? 6 : 10;
            for(int i=1;i<sides;++i) {
                const double a=tau*i/sides+angle,b=tau*(i+1)/sides+angle;
                triangle(center,center+Vec3{std::cos(b)*r*.65,0,std::sin(b)*r*.65},center+Vec3{std::cos(a)*r*.65,0,std::sin(a)*r*.65},leaves);
            }
        }
        if(object.plant.size>=.5) flower({0,level+.035,0},floral.radius,870);
        return faces;
    }
    if(object.species==Species::Sphagnum || object.species==Species::ForestMoss) {
        crown({0,h*.35,0},{r,h*.65,r*.85},leaves,880);return faces;
    }
    if(object.species==Species::Palm || object.species==Species::TreeFern) {
        const bool palm=object.species==Species::Palm;
        const Vec3 top{palm ? h*.07 : 0,h*.82,0};
        tube({0,-.15,0},top,object.collisionRadius(),h*.012,{.37f,.29f,.18f});
        sheets=true;const int fronds=simple ? 6 : 9,segments=simple ? 3 : 6;
        for(int leaf=0;leaf<fronds;++leaf) {
            const Vec3 dir{std::cos(tau*leaf/fronds),0,std::sin(tau*leaf/fronds)},side{-dir.z,0,dir.x};
            const auto point=[&](double t){return top+dir*(r*t)+Vec3{0,h*(.22*std::sin(pi*t)-.12*t*t),0};};
            for(int j=0;j<segments;++j) {
                const double a=static_cast<double>(j)/segments,b=static_cast<double>(j+1)/segments;
                const double width=r*(palm ? .12 : .18)*std::sin(pi*(a+b)/2);
                const double flutter=r*.025,phase=tau*randomUnit(object.id+static_cast<unsigned>(leaf)+192);
                triangle(point(a),point(b)+side*width,point(b),leaves,{flutter*a*a,flutter*b*b,flutter*b*b},phase);
                triangle(point(a),point(b),point(b)-side*width,leaves,{flutter*a*a,flutter*b*b,flutter*b*b},phase);
            }
        }
        return faces;
    }
    if(object.species==Species::Bamboo) {
        for(int stem=0;stem<(simple ? 2 : 4);++stem) {
            const double angle=tau*stem/4;const Vec3 base{std::cos(angle)*r*.25,0,std::sin(angle)*r*.25};
            const Vec3 top=base+Vec3{std::cos(angle)*r*.4,h*(.8+.2*randomUnit(object.id+stem)),std::sin(angle)*r*.4};
            tube(base,top,h*.009,h*.005,{.34f,.43f,.16f});sheets=true;
            for(int level=2;level<=5;++level) for(int side:{-1,1}) {
                const Vec3 joint=base+(top-base)*(level/6.);
                const Vec3 tip=joint+Vec3{side*r*.65,h*.08,side*r*.3};
                triangle(joint,tip+Vec3{0,h*.04,r*.12},tip,leaves);triangle(joint,tip,tip-Vec3{0,h*.02,r*.12},leaves);
            }
            sheets=false;
        }
        return faces;
    }
    if(object.species==Species::Monstera || object.species==Species::Bromeliad) {
        sheets=true;const bool broad=object.species==Species::Monstera;const int leavesCount=simple ? 5 : 8;
        for(int leaf=0;leaf<leavesCount;++leaf) {
            const double angle=tau*leaf/leavesCount;const Vec3 dir{std::cos(angle),0,std::sin(angle)},side{-dir.z,0,dir.x};
            const Vec3 joint=dir*(r*.08)+Vec3{0,broad ? h*.25 : 0,0};
            const auto mid=joint+dir*(r*.6)+Vec3{0,h*.65,0},tip=joint+dir*r+Vec3{0,h*.42,0};
            const double width=r*(broad ? .32 : .10);
            triangle(joint,mid+side*width,tip,leaves);triangle(joint,tip,mid-side*width,leaves);
            if(broad && !simple) for(int lobe=1;lobe<=3;++lobe) for(int sign:{-1,1}) {
                const auto center=joint+(tip-joint)*(lobe/5.);
                triangle(center,center+dir*(r*.2)+side*(sign*width*.9),center+dir*(r*.25),leaves);
            }
        }
        if(!broad) flower({0,h,0},floral.radius,1990);
        return faces;
    }
    if(object.species==Species::Reed || object.species==Species::Cattail || object.species==Species::Sedge || object.species==Species::Marram || object.species==Species::Pondweed) {
        const int stems=simple ? 3 : 5;sheets=true;
        for(int i=0;i<stems;++i) {
            const double angle=tau*i/stems;const Vec3 direction{std::cos(angle),0,std::sin(angle)},side{-direction.z,0,direction.x};
            const auto base=direction*(r*.25),tip=base+Vec3{0,h*(.72+.28*randomUnit(object.id+static_cast<unsigned>(i))),0};
            triangle(base-side*.009,tip,base+side*.009,leaves);
            for(int j=1;j<=4;++j) {
                const auto joint=base+(tip-base)*(j*.16);const auto middle=joint+direction*(r*.55)+Vec3{0,h*.12,0};
                const auto end=joint+direction*r+Vec3{0,h*(object.species==Species::Pondweed ? .05 : .07),0};
                const double w=r*(object.species==Species::Pondweed ? .22 : .065);
                triangle(joint,middle+side*w,end,leaves);triangle(joint,end,middle-side*w,leaves);
            }
            if(object.species==Species::Cattail) {
                if(std::max({flowers.buds,flowers.bloom,flowers.seeds})>.02)
                    tube(tip-Vec3{0,h*.18,0},tip,h*.024,h*.022,flowers.buds>flowers.bloom+flowers.seeds ? leaves : Color{.34f,.20f,.08f});
            } else flower(tip,floral.radius,static_cast<unsigned>(890+i));
        }
        return faces;
    }
    if(traits.aquatic || object.species==Species::Fern) {
        sheets=true;
        if(object.species==Species::Kelp) {
            // A holdfast, flexible stipe and alternating broad blades.
            tube({0,0,0},{r*.4,h,0},h*.009,h*.003,{.34f,.29f,.10f});
            for(int i=1;i<9;++i) {
                const double y=h*i/10,side=i%2 ? 1.0 : -1.0;
                const Vec3 a{r*.4*i/10,y,0},b=a+Vec3{r*side,y*.06,r*.5};
                triangle(a,b+Vec3{0,h*.12,0},b+Vec3{r*side*.3,0,-r*.4},leaves);
                triangle(a,b+Vec3{r*side*.3,0,-r*.4},b-Vec3{0,h*.06,0},leaves);
            }
        } else if(object.species==Species::Fern) {
            for(int i=0;i<7;++i) {
                const Vec3 direction{std::cos(tau*i/7),0,std::sin(tau*i/7)};
                const Vec3 side=cross(direction,Vec3{0,1,0});
                for(int j=1;j<6;++j) {
                    const double f=j/6.0;
                    const Vec3 a=direction*(r*f)+Vec3{0,h*std::sin(f*pi*.65),0};
                    const Vec3 b=direction*(r*(f-.2))+Vec3{0,h*std::sin(std::max(0.0,f-.2)*pi*.65),0};
                    triangle(b,a+side*(r*.23*(1-f)),a,leaves);
                    triangle(b,a,a-side*(r*.23*(1-f)),leaves);
                }
            }
        } else {
            const int blades=object.species==Species::Rockweed ? 9 : 7;
            for(int i=0;i<blades;++i) {
                const Vec3 side{std::cos(tau*i/blades),0,std::sin(tau*i/blades)};
                for(int j=0;j<4;++j) {
                    const auto point=[&](double f) { return side*(r*(.2+.65*f*f))+Vec3{0,h*f*(.65+.35*randomUnit(object.id+static_cast<unsigned>(i))),0}; };
                    const double a=j/4.0,b=(j+1)/4.0;
                    const double width=r*(object.species==Species::Rockweed ? .19 : .07);
                    triangle(point(a)-side*width*(1-a),point(a)+side*width*(1-a),point(b)+side*width*(1-b),leaves);
                    triangle(point(a)-side*width*(1-a),point(b)+side*width*(1-b),point(b)-side*width*(1-b),leaves);
                }
            }
        }
        if(object.species==Species::Seagrass) flower({r*.2,h*.7,0},floral.radius,801);
        return faces;
    }
    switch(object.kind) {
        case DetailKind::Rock:
            crown({0,h*0.32,0},{r,h*0.68,r*0.82},{0.46f*variation,0.43f*variation,0.36f*variation},101);
            break;
        case DetailKind::Tree: {
            const Color bark=object.species==Species::Birch ? Color{.78f,.77f,.69f} : Color{.27f,.19f,.12f};
            tube({0,-0.4,0},{0,h*0.72,0},object.collisionRadius(),h*0.008,bark);
            if(object.plant.stage==GrowthStage::Dead) {
                for(int i=0;i<3;++i) tube({0,h*.4,0},{r*std::cos(tau*i/3),h*.75,r*std::sin(tau*i/3)},h*.014,h*.003,bark);
                break;
            }
            if(object.evergreen) {
                const int layers=simple ? 3 : 5;
                const bool giant=object.species==Species::Redwood;
                for(int layer=0;layer<layers;++layer) {
                    const double t=static_cast<double>(layer)/layers;
                    const double base=h*((giant ? .42 : .16)+t*(giant ? .45 : .64)),width=r*(1-t*.82);
                    for(int i=0;i<8;++i) {
                        const Vec3 a{width*std::cos(tau*i/8),base,width*std::sin(tau*i/8)};
                        const Vec3 b{width*std::cos(tau*(i+1)/8),base,width*std::sin(tau*(i+1)/8)};
                        triangle(a,{0,std::min(h,base+h*.32),0},b,leaves);
                        triangle({0,base,0},a,b,{0.13f,0.29f,0.18f});
                        if(leafDetail) {
                            const bool previous=sheets;sheets=true;
                            const auto dir=normalized(Vec3{a.x,0,a.z}),side=Vec3{-dir.z,0,dir.x};
                            const double size=clamp(width*.15,.08,.4),phase=tau*randomUnit(object.id+static_cast<unsigned>(layer*8+i)+3800);
                            for(int twig=0;twig<3;++twig) {
                                const auto joint=a+side*(size*(twig-1)*.5);
                                triangle(joint,joint+dir*size+side*(size*.3)+Vec3{0,size*.2,0},joint+dir*(size*1.8),leaves,{0,size*.05,size*.12},phase,true);
                                triangle(joint,joint+dir*(size*1.8),joint+dir*size-side*(size*.3)+Vec3{0,size*.2,0},leaves,{0,size*.12,size*.05},phase,true);
                            }
                            sheets=previous;
                        }
                    }
                }
            } else {
                const bool flat=object.species==Species::Acacia;
                crown({0,h*(flat ? .86 : .73),0},{r,h*(flat ? .14 : .27),r},leaves,200);
                if(object.species==Species::Willow) {
                    for(int i=0;i<(simple ? 5 : 8);++i) {
                        const double angle=tau*i/(simple ? 5 : 8);const Vec3 edge{std::cos(angle)*r*.75,h*.72,std::sin(angle)*r*.75};
                        crown(edge-Vec3{0,h*.19,0},{r*.28,h*.29,r*.28},leaves,static_cast<unsigned>(1400+i*51));
                    }
                }
                if(!simple) for(int i=0;i<3;++i) {
                    const double angle=tau*i/3+0.4;
                    const Vec3 branch{std::cos(angle)*r*0.65,h*(0.56+i*0.055),std::sin(angle)*r*0.65};
                    tube({0,h*0.38,0},branch,h*0.012,h*0.004,bark);
                    crown(branch,{r*0.62,h*0.17,r*0.62},leaves,static_cast<std::uint64_t>(300+i*80));
                }
            }
            if(!simple && object.height>12 && (tropicalCanopy(object.species) || object.species==Species::Redwood)) {
                // Buttress wedges and branch-rooted hanging lianas. These scale
                // with their host; they have no separate ecological reservoir.
                for(int root=0;root<4;++root) {
                    const double a=tau*root/4;const Vec3 dir{std::cos(a),0,std::sin(a)},side{-dir.z,0,dir.x};
                    const auto tip=dir*(h*.055),base=dir*(h*.02),top=base+Vec3{0,h*.065,0};
                    const auto left=base+side*(h*.008),rightRoot=base-side*(h*.008);
                    triangle(left,tip,top,bark);triangle(tip,rightRoot,top,bark);triangle(rightRoot,left,top,bark);triangle(left,rightRoot,tip,bark);
                }
                for(unsigned vine=0;vine<object.lianas();++vine) {
                    const double a=tau*vine/object.lianas()+.4,radius=r*(.45+.3*randomUnit(object.id+vine+1910));
                    const Vec3 start{std::cos(a)*radius,h*.75,std::sin(a)*radius};
                    const double drop=h*(.38+.22*randomUnit(object.id+vine+1920));
                    const auto point=[&](double t){return start+Vec3{std::sin(t*pi)*r*.10,-drop*t,std::sin(t*pi*2+vine)*r*.05};};
                    for(int segment=0;segment<6;++segment) tube(point(segment/6.),point((segment+1)/6.),h*.0008,h*.0007,{.22f,.28f,.10f});
                    if(object.species==Species::StranglerFig) tube(point(1),{start.x,0,start.z},h*.0014,h*.0017,bark);
                }
            }
            if(floral.form!=FlowerForm::None) {
                const bool flat=object.species==Species::Acacia;const int sides=simple ? 6 : 8;
                for(int row=1;row<3;++row) for(int i=0;i<sides;++i) {
                    const double lat=-pi/2+pi*row/(simple ? 3 : 4),angle=tau*i/sides;
                    const double rough=.82+.30*randomUnit(object.id+200+static_cast<std::uint64_t>(row*17+i));
                    const Vec3 tip{std::cos(lat)*std::cos(angle)*r*rough,h*(flat ? .86 : .73)+std::sin(lat)*h*(flat ? .14 : .27),std::cos(lat)*std::sin(angle)*r*rough};
                    flower(tip,floral.radius,static_cast<unsigned>(1200+row*17+i));
                }
            }
            break;
        }
        case DetailKind::Shrub:
            crown({0,h*0.43,0},{r,h*0.57,r},leaves,500);
            if(object.species==Species::Heather) for(int i=0;i<(simple ? 6 : 16);++i) {
                const int sides=simple ? 6 : 8,row=simple ? 2 : 2+i/8,column=i%sides;
                const double lat=-pi/2+pi*row/(simple ? 3 : 4),angle=tau*column/sides;
                const double rough=.82+.30*randomUnit(object.id+500+static_cast<std::uint64_t>(row*17+column));
                const Vec3 tip{std::cos(lat)*std::cos(angle)*r*rough*1.02,h*(.43+.57*std::sin(lat)),std::cos(lat)*std::sin(angle)*r*rough*1.02};
                flower(tip,floral.radius,static_cast<unsigned>(700+i));
            }
            break;
        case DetailKind::Grass:
            sheets=true;
            if(object.species>=Species::Daisy) {
                const int stems=simple ? 3 : 5;
                for(int i=0;i<stems;++i) {
                    const double angle=tau*i/stems,scale=.68+.32*randomUnit(object.id+static_cast<unsigned>(600+i));
                    const Vec3 side{std::cos(angle),0,std::sin(angle)},front{-side.z,0,side.x};
                    const Vec3 base=side*(r*.22),tip=base+side*(r*.55)+Vec3{0,h*scale,0};
                    triangle(base-front*.004,base+front*.004,tip+front*.002,leaves);
                    triangle(base-front*.004,tip+front*.002,tip-front*.002,leaves);
                    for(int j=1;j<=3;++j) {
                        const auto joint=base+(tip-base)*(j*.20);const double width=r*(object.species==Species::Clover ? .38 : .19);
                        for(int leaflet=0;leaflet<(object.species==Species::Clover ? 3 : 1);++leaflet) {
                            const auto direction=rotate(side,{0,1,0},tau*leaflet/3)*(j%2 ? 1. : -1.);
                            const auto middle=joint+direction*(r*.45)+Vec3{0,h*.06,0};
                            triangle(joint,middle+front*width,middle+direction*(r*.35),leaves);
                            triangle(joint,middle+direction*(r*.35),middle-front*width,leaves);
                        }
                    }
                    if(object.species==Species::Fireweed) for(int j=0;j<(simple ? 4 : 9);++j) {
                        const double a=tau*j/3;flower(tip-Vec3{0,h*j*.025,0}+Vec3{std::cos(a)*r*.25,0,std::sin(a)*r*.25},floral.radius,static_cast<unsigned>(900+i*11+j));
                    } else flower(tip,floral.radius,static_cast<unsigned>(900+i));
                }
                break;
            }
            for(int i=0;i<5;++i) {
                const double angle=tau*i/5;
                const Vec3 side{std::cos(angle),0,std::sin(angle)};
                const Vec3 base=side*(r*0.35);
                triangle(base-side*0.06,base+side*0.06,base+Vec3{r*0.3,h*(0.6+0.1*i),r*0.2},leaves);
                if(i<3) flower(base+Vec3{r*.3,h*(.6+.1*i),r*.2},floral.radius,static_cast<unsigned>(910+i));
            }
            break;
    }
    return faces;
}
} // namespace planet
